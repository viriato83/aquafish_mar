

export default class  Mortalidade{

    constructor(descricao,quantidade,data,idstock){
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.data = data;
        this.stocks={
            idstock:idstock
        }
    }
}
