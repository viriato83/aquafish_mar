export class Racao{
    
    constructor( 
           tipo,
         quantidade,
             quantidade_disp,
             data_entrada,
           
             quantidade_saida,
            valor_uni,
            valor_tot){
                this.tipo=tipo;
                this.quantidade=quantidade;
             this.quantidade_disp=quantidade_disp;
             this.data_entrada=data_entrada;
            
             this.quantidade_saida=quantidade_saida;
            this.valor_uni=valor_uni;
            this.valor_tot=valor_tot;

            }
}