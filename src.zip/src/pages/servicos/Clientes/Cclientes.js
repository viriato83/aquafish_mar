export default class Clientes{

    nome;
    localizacao;
    telefone;
  
    constructor(nome, localizacao, telefone,status_p){

        this.nome=nome;
        this.localizacao=localizacao;
        this.telefone=telefone;
        this.status_p=status_p;

    }
        
}