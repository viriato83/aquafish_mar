

export default function Footer(){
    return(  <footer>
        <p>&copy; 2024 Aquafish LDA. Todos os direitos reservados.</p>
    </footer>)
}