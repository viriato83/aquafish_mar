
export default function Content({children}){
    return(
        <section className="content">
                 <div className="mensagem">
                
                </div>
               {children}
      
        </section>
    )
}